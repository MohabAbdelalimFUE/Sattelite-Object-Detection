import io
import numpy as np
from fastapi import FastAPI, UploadFile, File , Request, Form
from keras.models import load_model
from PIL import Image
from fastapi.templating import Jinja2Templates

app = FastAPI()
templates = Jinja2Templates(directory="templates/")

def read_imagefile(image_enc) -> Image.Image:
    image = Image.open(io.BytesIO(image_enc))
    return image


def preprocessing(img: Image.Image):
    img = img.resize((256,256))
    img = np.asfarray(img)
    img = img / .255  # normalization
    img = np.reshape(img, [1, 256, 256, 3])  # convert it to tensor
    return img

@app.get('/')
def read_form():
    return 'Welcome'

@app.get("/predict")
def predict(request: Request):
    result = "Upload a pic"
    return templates.TemplateResponse('main.html', context={'request': request, 'result': result})

@app.post("/predict")
async def predict(request: Request, file: UploadFile = File(...)):
    img = read_imagefile(await file.read())
    img = preprocessing(img)
    model = load_model('recognize_images_upload.h5')
    model.summary()  # As a reminder.
    class_decode = {0: "gloves", 1: "shoes"}
    class_output = model.predict(img)
    return templates.TemplateResponse('main.html', context={'request': request, 'result': class_decode.get(int(class_output))})

