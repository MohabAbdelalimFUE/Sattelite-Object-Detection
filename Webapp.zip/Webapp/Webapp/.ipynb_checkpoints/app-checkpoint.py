from flask import Flask, render_template, request
import pickle
pkl_filename = './RF_model_1000.pkl'
with open(pkl_filename, 'rb') as file:  
    model = pickle.load(file)
app = Flask(__name__)

#dic = {0 : 'Cat', 1 : 'Dog'}




# routes
@app.route("/", methods=['GET', 'POST'])
def main():
	return render_template("index.html")

@app.route("/submit", methods = [ 'POST'])
def get_output():
	if request.method == 'POST':
		img = request.files['my_image']

		img_path = "test/" + img.filename	
		img.save(img_path)

		

	return render_template("index.html", img_path = img_path)


if __name__ =='__main__':
	#app.debug = True
	app.run()